select *from staff_master;
select *from department_master;
select *from designation_master;
select *from emp;

/*3.1.1*/
select sm.staff_code,sm.staff_name,sm.dept_code,dm.dept_name,sm.staff_sal from 
staff_master sm inner join
department_master dm on sm.DEPT_CODE=dm.dept_code;  --3.1.1

/*3.1.2*/
select sm.staff_code Staff#,sm.staff_name Staff,dm.dept_name,sm.mgr_code Mgr#,s.staff_name Manager from 
staff_master sm,staff_master s,department_master dm 
where sm.dept_code=dm.dept_code and s.staff_code=sm.mgr_code;  --3.1.2

select *from student_master;
select *from book_master;
select *from BOOK_TRANSACTIONS;

/*3.1.3*/
select sm.student_code,sm.student_name,bt.book_code,bm.book_name from 
student_master sm,book_master bm, book_transactions bt 
where bt.book_code=bm.book_code and bt.student_code=sm.student_code and
bt.BOOK_EXPECTED_RETURN_DATE='08-06-11';  --3.1.3

/*3.1.6*/
select staff_code,staff_name,staff_sal from staff_master where staff_sal<
(select avg(staff_sal) from staff_master); --3.1.6











