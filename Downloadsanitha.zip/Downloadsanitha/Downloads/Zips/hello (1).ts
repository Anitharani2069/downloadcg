var fruits: string[] = ['Apple', 'Orange', 'Banana'];
for(var index in fruits)
{
console.log(fruits[index]);
}